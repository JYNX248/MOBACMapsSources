package com.jon.common.service;

public interface ThreadErrorListener {
    void reportError(Throwable throwable);
}
